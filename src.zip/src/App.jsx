import Encabezado from "./components/encabezado";
import TodoApp from "./components/TodoApp";

function App() {
    return (
        <>
            <Encabezado />
            <TodoApp />
        </>
    );
}

export default App;
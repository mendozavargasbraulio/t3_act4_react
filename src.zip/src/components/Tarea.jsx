function Tarea({ nombre, completada, onCompletar }) {
    return (
        <div>
            <p>
                {nombre} {completada ? "✅" : "❌"}
            </p>

            <button onClick={onCompletar}>
                {completada ? "Marcar pendiente" : "Completar"}
            </button>
        </div>
    );
}

export default Tarea;
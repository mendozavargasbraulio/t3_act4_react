function Encabezado() {
    return (
        <header>
            <h1>Lista de tareas</h1>
            <p>Organiza tus actividades pendientes</p>
        </header>
    );
}

export default Encabezado;
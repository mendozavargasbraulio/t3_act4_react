import { useState } from "react";
import Tarea from "./Tarea";
import styles from "./TodoApp.module.css";

function TodoApp() {
    const [tareas, setTareas] = useState([
        { id: 1, nombre: "Ver video de React", completada: true },
        { id: 2, nombre: "Practicar componentes", completada: false },
        { id: 3, nombre: "Subir proyecto a GitHub", completada: false }
    ]);

    const completarTarea = (id) => {
        const nuevasTareas = tareas.map((tarea) => {
            if (tarea.id === id) {
                return {
                    ...tarea,
                    completada: !tarea.completada
                };
            }

            return tarea;
        });

        setTareas(nuevasTareas);
    };

    return (
        <div className={styles.contenedor}>
            <h2>Mis tareas</h2>

            {tareas.length === 0 ? (
                <p>No hay tareas disponibles.</p>
            ) : (
                tareas.map((tarea) => (
                    <Tarea
                        key={tarea.id}
                        nombre={tarea.nombre}
                        completada={tarea.completada}
                        onCompletar={() => completarTarea(tarea.id)}
                    />
                ))
            )}
        </div>
    );
}

export default TodoApp;